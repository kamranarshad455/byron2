import React from "react";
import LandingPage from "./Pages/LandingPage";

const App = () => {
  return (
    <>
      <LandingPage />
    </>
  );
};

export default App;
